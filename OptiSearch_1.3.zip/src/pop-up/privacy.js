document.addEventListener("DOMContentLoaded", async () => {
  console.log('peta8raszfd')
  document.querySelectorAll('a').forEach(console.log)
  hrefPopUp();
})
